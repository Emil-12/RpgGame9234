#pragma once
#include "Hero.h"
#include <iostream>

struct World
{
	Hero hero;

	void location1();
	void location2();
	void location3();
	void location4();
};