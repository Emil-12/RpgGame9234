#pragma once


struct Item
{
	int gold;
	short sword;
};