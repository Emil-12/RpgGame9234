#pragma once
#include <iostream>
#include "World.h"

struct Game
{
	World world;

	void menu();
};

