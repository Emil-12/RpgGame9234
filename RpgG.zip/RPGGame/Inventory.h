#pragma once
#include "Item.h"

struct Inventory
{
	Item items[20];
};